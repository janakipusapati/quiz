from django.urls import path
from . import views as quiz_views

app_name = 'quiz'

urlpatterns = [
    path('', quiz_views.home, name='home'),
    path('user-home', quiz_views.user_home, name='user_home'),
    path('play/', quiz_views.play, name='play'),
    path('leaderboard/', quiz_views.leaderboard, name='leaderboard'),
    path('submission-result/(?P<attempted_question_pk>\d+)/', quiz_views.submission_result, name='submission_result'),
    path('login/', quiz_views.login_view, name='login'),
    path('logout/', quiz_views.logout_view, name='logout'),
    path('register/', quiz_views.register, name='register'),

]
